import webbrowser


github=webbrowser.open("https://github.com/ZakariaHibaoui/lp2e")