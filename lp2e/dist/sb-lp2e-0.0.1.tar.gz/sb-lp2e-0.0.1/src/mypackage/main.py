import webbrowser


webbrowser.open("https://github.com/ZakariaHibaoui/lp2e/issues")